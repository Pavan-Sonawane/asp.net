﻿using Domain.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Services.CustomService.LeaveRequestService
{
    public interface ILeaveRequest
    {
        IEnumerable<LeaveRequestViewModel> GetAllLeaveRequests();
        LeaveRequestViewModel GetLeaveRequestById(int leaveRequestId);
        void CreateLeaveRequest(LeaveInsertViewModel leaveInsertViewModel);
        void UpdateLeaveRequest(int leaveRequestId, LeaveInsertViewModel leaveInsertViewModel);
        void DeleteLeaveRequest(int leaveRequestId);
    }
}
