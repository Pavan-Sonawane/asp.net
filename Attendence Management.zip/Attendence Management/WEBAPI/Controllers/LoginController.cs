﻿using Domain.Helpers;
using Domain.Models;
using Domain.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Repository.common;
using Repository.Context;
using System.Net;
using System.Threading.Tasks;
using WebApi.Middleware.Auth;

namespace WEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly MainDbcontext _context;
        private readonly IJWTAuthManager _authManager;

        public LoginController(MainDbcontext context, IJWTAuthManager authManager)
        {
            _context = context;
            _authManager = authManager;
        }

        [HttpPost("LoginUser")]
        [AllowAnonymous]
        public async Task<IActionResult> UserLogin(LoginModel loginUser)
        {
            Response<string> response = new Response<string>();

            if (ModelState.IsValid)
            {
                // Fetch user from the database based on username
                var user = await _context.Users.FirstOrDefaultAsync(x => x.Username == loginUser.Username);

                if (user != null && user.Password == loginUser.Password)
                {
                    // Valid credentials, generate JWT token
                    response.Message = _authManager.GenerateJWT(user);
                    response.Status = (int)HttpStatusCode.OK;
                    return Ok(response);
                }

                else
                {
                    // Invalid credentials
                    response.Message = "Invalid Username / Password, Please Enter Valid Credentials...!";
                    response.Status = (int)HttpStatusCode.NotFound;
                    return NotFound(response);
                }
            }
            else
            {
                // Invalid login information
                response.Message = "Invalid Login Information, Please Enter Valid Credentials...!";
                response.Status = (int)HttpStatusCode.NotAcceptable;
                return BadRequest(response);
            }
        }
    }
}
